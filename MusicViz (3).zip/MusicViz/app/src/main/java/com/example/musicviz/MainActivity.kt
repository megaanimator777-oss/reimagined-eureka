package com.example.musicviz

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var img: ImageView
    private lateinit var st: TextView
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { Live.bmp?.let { img.setImageBitmap(it) }; st.text = Live.status; h.postDelayed(this, 40) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val wid = intent?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (wid != AppWidgetManager.INVALID_APPWIDGET_ID) // нужно, если лаунчер открыл настройки при добавлении виджета
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
        val cfg = Cfg(this)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        fun label(t: String) = l.addView(TextView(this).apply { text = t; textSize = 13f; setPadding(0, 24, 0, 0) })
        fun btn(t: String, a: () -> Unit) = l.addView(Button(this).apply { text = t; setOnClickListener { a() } })
        fun slider(t: String, max: Int, cur: Int, on: (Int) -> Unit) { label(t); l.addView(seek(max, cur, on)) }

        img = ImageView(this).apply { setBackgroundColor(0xFF1A1A1A.toInt()) }
        l.addView(img, LinearLayout.LayoutParams(-1, 520))
        st = TextView(this).apply { textSize = 12f }
        l.addView(st)

        btn("1. Разрешить микрофон и уведомления") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("2. Отключить оптимизацию батареи") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        btn("3. Запустить визуализацию") { startForegroundService(Intent(this, VisualizerService::class.java)) }
        btn("Остановить") { stopService(Intent(this, VisualizerService::class.java)) }

        label("Источник звука")
        l.addView(spinner(listOf("Авто (Visualizer, при тишине — микрофон)", "Только Visualizer", "Только микрофон"), cfg.source) { cfg.source = it })
        label("Режим")
        l.addView(spinner(Render.MODES, cfg.mode) { cfg.mode = it })
        label("Частота кадров (ниже — если рывки или греется)")
        l.addView(spinner(VisualizerService.FPS.map { "$it кадров/с" }, cfg.fps) { cfg.fps = it })

        slider("Чувствительность", 100, cfg.sens) { cfg.sens = it }
        slider("Плавность (вправо — мягче)", 100, cfg.smooth) { cfg.smooth = it }
        slider("Прозрачность визуализации", 95, 100 - cfg.alpha) { cfg.alpha = 100 - it }
        slider("Затемнение фона (0 — совсем нет)", 100, cfg.bg) { cfg.bg = it }
        slider("Количество полос", 24, cfg.bars - 8) { cfg.bars = it + 8 }

        colorRow(l, "Цвет 1", { cfg.colorA }, { cfg.colorA = it })
        l.addView(CheckBox(this).apply {
            text = "Градиент (второй цвет)"; isChecked = cfg.grad == 1
            setOnCheckedChangeListener { _, b -> cfg.grad = if (b) 1 else 0 }
        })
        colorRow(l, "Цвет 2", { cfg.colorB }, { cfg.colorB = it })

        label("Виджет: долгое нажатие на рабочем столе → Виджеты → Music Visualizer. Размер любой: растяните за рамку. Нажатие на виджет — старт/стоп.")
        setContentView(ScrollView(this).apply { addView(l) })
    }

    private fun spinner(items: List<String>, sel: Int, on: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(sel)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { on(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun seek(max: Int, start: Int, on: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max; progress = start
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { on(v) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun colorRow(l: LinearLayout, title: String, get: () -> Int, set: (Int) -> Unit) {
        val hsv = FloatArray(3); Color.colorToHSV(get(), hsv)
        val sw = View(this)
        fun apply() { val c = Color.HSVToColor(hsv); sw.setBackgroundColor(c); set(c) }
        l.addView(TextView(this).apply { text = title; setPadding(0, 24, 0, 8) })
        l.addView(sw, LinearLayout.LayoutParams(-1, 56))
        l.addView(seek(359, hsv[0].toInt()) { hsv[0] = it.toFloat(); apply() })
        l.addView(seek(100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f; apply() })
        l.addView(seek(100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f; apply() })
        apply()
    }

    override fun onResume() { super.onResume(); Live.watching = true; h.post(tick) }
    override fun onPause() { super.onPause(); Live.watching = false; h.removeCallbacks(tick) }
}
