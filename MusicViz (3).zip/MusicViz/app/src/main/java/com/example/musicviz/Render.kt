package com.example.musicviz

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.*
import kotlin.math.*

object Render {
    val MODES = listOf("Столбики", "Зеркальные столбики", "Волна", "Круг", "LED-столбики", "Пульс", "Осциллограф", "Цветок")

    /** Размер картинки под реальный размер виджета (любая сетка: 1x1, 3x3, 4x2 ...). */
    fun sizeOf(c: Context, m: AppWidgetManager, id: Int): Pair<Int, Int> {
        val o = m.getAppWidgetOptions(id); val d = c.resources.displayMetrics.density
        val land = c.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        var w = ((if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)) * d).toInt()
        var h = ((if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT)) * d).toInt()
        if (w < 40 || h < 40) { w = 360; h = 360 }
        val s = min(1f, 480f / max(w, h))
        return max(32, (w * s).toInt()) to max(32, (h * s).toInt())
    }

    private fun curve(xs: FloatArray, ys: FloatArray, closed: Boolean): Path {
        val n = xs.size; val p = Path()
        if (closed) {
            p.moveTo((xs[n - 1] + xs[0]) / 2, (ys[n - 1] + ys[0]) / 2)
            for (i in 0 until n) { val j = (i + 1) % n; p.quadTo(xs[i], ys[i], (xs[i] + xs[j]) / 2, (ys[i] + ys[j]) / 2) }
            p.close()
        } else {
            p.moveTo(xs[0], ys[0])
            for (i in 1 until n) p.quadTo(xs[i - 1], ys[i - 1], (xs[i - 1] + xs[i]) / 2, (ys[i - 1] + ys[i]) / 2)
            p.lineTo(xs[n - 1], ys[n - 1])
        }
        return p
    }

    fun draw(c: Canvas, w: Int, h: Int, lv: FloatArray, wave: FloatArray, cfg: Cfg) {
        c.drawColor(Color.argb(cfg.bg * 255 / 100, 0, 0, 0), PorterDuff.Mode.SRC)
        val a = cfg.colorA; val b = if (cfg.grad == 1) cfg.colorB else a
        val al = cfg.alpha * 255 / 100
        val W = w.toFloat(); val H = h.toFloat(); val m = min(W, H); val cx = W / 2; val cy = H / 2
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, H, 0f, 0f, a, b, Shader.TileMode.CLAMP)
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; alpha = al
        }
        val n = cfg.bars
        fun v(i: Int, cnt: Int): Float {
            val s = i * lv.size / cnt; val e = min(lv.size, max(s + 1, (i + 1) * lv.size / cnt))
            var r = 0f; for (k in s until e) r = max(r, lv[k]); return r
        }
        fun avg(s: Int, e: Int): Float { var r = 0f; for (k in s until e) r += lv[k]; return r / (e - s) }
        when (cfg.mode) {
            0 -> {
                val bw = W / n; val g = bw * .18f; val rr = min(bw / 2, 10f)
                for (i in 0 until n) c.drawRoundRect(i * bw + g, H - max(3f, v(i, n) * H), (i + 1) * bw - g, H, rr, rr, p)
            }
            1 -> {
                val bw = W / n; val g = bw * .18f; val rr = min(bw / 2, 10f)
                for (i in 0 until n) { val hh = max(2f, v(i, n) * H / 2); c.drawRoundRect(i * bw + g, cy - hh, (i + 1) * bw - g, cy + hh, rr, rr, p) }
            }
            2 -> {
                val xs = FloatArray(n) { (it + .5f) * W / n }; val ys = FloatArray(n) { H - max(3f, v(it, n) * H * .95f) }
                val path = curve(xs, ys, false)
                val fill = Path(path).apply { lineTo(xs[n - 1], H); lineTo(xs[0], H); close() }
                p.alpha = al * 35 / 100; c.drawPath(fill, p)
                p.alpha = al; p.style = Paint.Style.STROKE; p.strokeWidth = max(3f, m * .02f); c.drawPath(path, p)
            }
            3 -> {
                val r0 = m * .2f; val rl = m * .28f; val t = n * 2
                p.style = Paint.Style.STROKE; p.strokeWidth = max(3f, m * .022f)
                for (i in 0 until t) {
                    val k = if (i < n) i else t - 1 - i; val ang = i * 2 * PI / t - PI / 2; val r1 = r0 + max(3f, v(k, n) * rl)
                    c.drawLine(cx + (r0 * cos(ang)).toFloat(), cy + (r0 * sin(ang)).toFloat(),
                        cx + (r1 * cos(ang)).toFloat(), cy + (r1 * sin(ang)).toFloat(), p)
                }
            }
            4 -> {
                val rows = 12; val bw = W / n; val ch = H / rows; val g = max(1f, min(bw, ch) * .14f)
                for (i in 0 until n) {
                    val lit = (v(i, n) * rows + .5f).toInt()
                    for (r in 0 until lit) c.drawRoundRect(i * bw + g, H - (r + 1) * ch + g, (i + 1) * bw - g, H - r * ch - g, 2f, 2f, p)
                }
            }
            5 -> {
                val bass = avg(0, 6); val mid = avg(6, 18); val hi = avg(18, lv.size)
                p.style = Paint.Style.FILL; p.alpha = al * 6 / 10; c.drawCircle(cx, cy, m * (.08f + .12f * bass), p)
                p.style = Paint.Style.STROKE; p.alpha = al
                p.strokeWidth = m * (.01f + .035f * bass); c.drawCircle(cx, cy, m * (.2f + .06f * bass), p)
                p.strokeWidth = m * (.008f + .025f * mid); c.drawCircle(cx, cy, m * (.3f + .05f * mid), p)
                p.strokeWidth = m * (.006f + .02f * hi); c.drawCircle(cx, cy, m * (.4f + .04f * hi), p)
            }
            6 -> {
                val pts = min(w, 160); val gain = (10.0.pow((cfg.sens - 50) / 50.0) * 1.5).toFloat(); val path = Path()
                for (i in 0 until pts) {
                    val s = wave[i * (wave.size - 1) / (pts - 1)]
                    val y = cy - (s * gain).coerceIn(-1f, 1f) * H * .45f; val x = i * W / (pts - 1)
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                p.style = Paint.Style.STROKE; p.strokeWidth = max(3f, m * .02f); c.drawPath(path, p)
            }
            else -> {
                val t = n * 2; val r0 = m * .16f; val rl = m * .3f
                val xs = FloatArray(t); val ys = FloatArray(t)
                for (i in 0 until t) {
                    val k = if (i < n) i else t - 1 - i; val ang = i * 2 * PI / t - PI / 2; val r = r0 + v(k, n) * rl
                    xs[i] = cx + (r * cos(ang)).toFloat(); ys[i] = cy + (r * sin(ang)).toFloat()
                }
                val path = curve(xs, ys, true)
                p.alpha = al * 35 / 100; c.drawPath(path, p)
                p.alpha = al; p.style = Paint.Style.STROKE; p.strokeWidth = max(3f, m * .018f); c.drawPath(path, p)
            }
        }
    }
}
