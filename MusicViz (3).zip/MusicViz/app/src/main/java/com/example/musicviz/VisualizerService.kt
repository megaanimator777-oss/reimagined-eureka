package com.example.musicviz

import android.app.*
import android.appwidget.AppWidgetManager
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.*
import android.media.audiofx.Visualizer
import android.os.IBinder
import android.os.PowerManager
import android.widget.RemoteViews
import kotlin.concurrent.thread
import kotlin.math.*

/**
 * Два потока: аудио (анализ звука, ~40 раз/с) и отрисовка (фиксированная частота кадров,
 * сглаживание по времени), поэтому анимация плавная и не зависит от темпа чтения звука.
 */
class VisualizerService : Service() {
    @Volatile private var viz: Visualizer? = null
    @Volatile private var mic: AudioRecord? = null
    @Volatile private var running = false
    @Volatile private var screenOn = true
    @Volatile private var state = 1 // 0 экран выключен, 1 музыка не играет, 2 играет
    private val target = FloatArray(BARS)
    private val wave = FloatArray(N)
    private var micFallback = false
    private var soundSeen = false
    private var lastSound = 0L
    private val cfg by lazy { Cfg(this) }
    private val screenRcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { screenOn = i.action == Intent.ACTION_SCREEN_ON }
    }

    companion object {
        const val N = 1024; const val BARS = 32
        val FPS = intArrayOf(15, 24, 30, 40)
        @Volatile var alive = false
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("viz", "Visualizer", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "viz").setContentTitle("Визуализатор работает")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
        try {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) {
            Live.status = "Система не разрешила запуск (выдано ли разрешение на микрофон?): ${e.message}"
            stopSelf(); return START_NOT_STICKY
        }
        if (i?.action == "toggle" && running) { stopSelf(); return START_NOT_STICKY }
        if (!running) {
            running = true; alive = true
            screenOn = getSystemService(PowerManager::class.java).isInteractive
            registerReceiver(screenRcv, IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF)
            })
            thread { audioLoop() }
            thread { renderLoop() }
        }
        return START_STICKY
    }

    private fun openViz() {
        viz = Visualizer(0).also { it.setEnabled(false); it.setCaptureSize(N); it.setEnabled(true) }
        soundSeen = false; lastSound = System.currentTimeMillis()
    }

    private fun openMic() {
        mic = AudioRecord(MediaRecorder.AudioSource.MIC, 44100, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, N * 4).also { it.startRecording() }
    }

    private fun close() {
        try { viz?.release() } catch (_: Exception) { }
        viz = null
        try { mic?.stop(); mic?.release() } catch (_: Exception) { }
        mic = null
    }

    private fun audioLoop() {
        val am = getSystemService(AudioManager::class.java)
        val buf = ShortArray(N); val wb = ByteArray(N)
        val re = DoubleArray(N); val im = DoubleArray(N)
        var lastMode = -1; var statusAt = 0L
        while (running) {
            try {
                val now = System.currentTimeMillis()
                val mode = cfg.source
                if (mode != lastMode) { close(); micFallback = false; lastMode = mode }
                val useMic = mode == 2 || (mode == 0 && micFallback)
                // Экономия батареи: экран выключен или музыка не играет — ничего не слушаем
                if (!screenOn || !(useMic || am.isMusicActive)) {
                    close(); target.fill(0f); wave.fill(0f)
                    state = if (screenOn) 1 else 0
                    Live.status = if (screenOn) "Музыка не играет — ожидание" else "Экран выключен — пауза"
                    Thread.sleep(300); continue
                }
                state = 2
                if (viz == null && mic == null) {
                    if (useMic) openMic() else try { openViz() } catch (e: Exception) {
                        if (mode == 0) { micFallback = true; continue } else throw e
                    }
                }
                val m = mic
                if (m != null) {
                    if (m.read(buf, 0, N) < N) { Thread.sleep(20); continue }
                    for (k in 0 until N) re[k] = buf[k] / 32768.0
                } else {
                    viz!!.getWaveForm(wb); Thread.sleep(25)
                    for (k in 0 until N) re[k] = ((wb[k].toInt() and 0xFF) - 128) / 128.0
                }
                var peak = 0.0
                for (k in 0 until N) {
                    wave[k] = re[k].toFloat(); peak = max(peak, abs(re[k]))
                    re[k] *= 0.5 - 0.5 * cos(2 * PI * k / (N - 1)); im[k] = 0.0
                }
                if (peak > 0.001) { lastSound = now; soundSeen = true }
                else if (viz != null && mode == 0 && !soundSeen && now - lastSound > 3000) { micFallback = true; close(); continue }
                fft(re, im)
                val gain = 10.0.pow((cfg.sens - 50) / 50.0)
                for (b in 0 until BARS) {
                    val lo = 1 + 400.0.pow(b / BARS.toDouble()).toInt()
                    val hi = max(lo + 1, 1 + 400.0.pow((b + 1) / BARS.toDouble()).toInt())
                    var mg = 0.0
                    for (k in lo until hi) mg = max(mg, hypot(re[k], im[k]) / N * 4)
                    target[b] = ((20 * log10(mg * gain + 1e-6) + 70) / 60).toFloat().coerceIn(0f, 1f)
                }
                if (now - statusAt > 500) {
                    statusAt = now
                    val src = if (mic != null) (if (mode == 0) "микрофон (запасной)" else "микрофон") else "системный Visualizer"
                    Live.status = "Источник: $src · уровень %.3f".format(peak)
                }
            } catch (e: Exception) {
                Live.status = "Ошибка: ${e.javaClass.simpleName} ${e.message}"
                try { Thread.sleep(300) } catch (_: InterruptedException) { }
            }
        }
    }

    private fun renderLoop() {
        val mgr = AppWidgetManager.getInstance(this)
        val cn = ComponentName(this, VisualizerWidget::class.java)
        val lv = FloatArray(BARS)
        val bmps = HashMap<Int, Bitmap>(); val sizes = HashMap<Int, Pair<Int, Int>>()
        val pv = arrayOf(Bitmap.createBitmap(400, 300, Bitmap.Config.ARGB_8888), Bitmap.createBitmap(400, 300, Bitmap.Config.ARGB_8888))
        var pi = 0; var ids = IntArray(0); var idsAt = 0L; var flat = false
        var prev = System.nanoTime()
        while (running) {
            try {
                val t0 = System.nanoTime()
                val dt = ((t0 - prev) / 1e6f).coerceIn(1f, 200f); prev = t0
                if (t0 / 1_000_000 - idsAt > 1000) {
                    idsAt = t0 / 1_000_000; ids = mgr.getAppWidgetIds(cn)
                    for (id in ids) sizes[id] = Render.sizeOf(this, mgr, id)
                }
                // Сглаживание по времени: быстро вверх, плавно вниз — не зависит от частоты кадров
                val ta = 20f + cfg.smooth * 0.6f; val td = 60f + cfg.smooth * 4f
                var mx = 0f
                for (b in 0 until BARS) {
                    val t = target[b]
                    lv[b] += (t - lv[b]) * (1f - exp(-dt / (if (t > lv[b]) ta else td)))
                    mx = max(mx, lv[b])
                }
                if (Live.watching) {
                    pi = pi xor 1
                    Render.draw(Canvas(pv[pi]), 400, 300, lv, wave, cfg); Live.bmp = pv[pi]
                }
                val settled = state != 2 && mx < 0.01f
                if (state == 0 || ids.isEmpty() || (settled && flat)) { Thread.sleep(if (Live.watching) 60 else 150); prev = System.nanoTime(); continue }
                if (settled) lv.fill(0f)
                flat = settled
                for (id in ids) {
                    val (w, h) = sizes[id] ?: (360 to 360)
                    var bmp = bmps[id]
                    if (bmp == null || bmp.width != w || bmp.height != h) { bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); bmps[id] = bmp }
                    Render.draw(Canvas(bmp), w, h, lv, wave, cfg)
                    val rv = RemoteViews(packageName, R.layout.widget)
                    rv.setImageViewBitmap(R.id.img, bmp)
                    mgr.partiallyUpdateAppWidget(id, rv)
                }
                val spent = (System.nanoTime() - t0) / 1_000_000
                Thread.sleep(max(1L, 1000L / FPS[cfg.fps.coerceIn(0, FPS.size - 1)] - spent))
            } catch (e: Exception) {
                Live.status = "Ошибка отрисовки: ${e.javaClass.simpleName} ${e.message}"
                try { Thread.sleep(300) } catch (_: InterruptedException) { }
            }
        }
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size; var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val t = re[i]; re[i] = re[j]; re[j] = t }
        }
        var len = 2
        while (len <= n) {
            val a = -2 * PI / len; val wr = cos(a); val wi = sin(a)
            var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                for (k in 0 until len / 2) {
                    val x = i + k; val y = x + len / 2
                    val tr = re[y] * cr - im[y] * ci; val ti = re[y] * ci + im[y] * cr
                    re[y] = re[x] - tr; im[y] = im[x] - ti; re[x] += tr; im[x] += ti
                    val t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t
                }
                i += len
            }
            len = len shl 1
        }
    }

    override fun onDestroy() {
        running = false; alive = false
        try { unregisterReceiver(screenRcv) } catch (_: Exception) { }
        close()
        Live.status = "Сервис не запущен"
        super.onDestroy()
    }
}
