package com.example.musicviz

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Bundle
import android.widget.RemoteViews

class VisualizerWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        // Нажатие на виджет — старт/стоп. Настройки: долгое нажатие на виджет → «Настройки» или иконка приложения.
        val toggle = PendingIntent.getForegroundService(c, 1,
            Intent(c, VisualizerService::class.java).setAction("toggle"), PendingIntent.FLAG_IMMUTABLE)
        for (id in ids) {
            val rv = RemoteViews(c.packageName, R.layout.widget)
            rv.setOnClickPendingIntent(R.id.img, toggle); rv.setOnClickPendingIntent(R.id.root, toggle)
            if (!VisualizerService.alive) { // пока сервис не запущен — рисуем «пустой» спектр, чтобы виджет был виден
                val (w, h) = Render.sizeOf(c, m, id)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                Render.draw(Canvas(bmp), w, h, FloatArray(32), FloatArray(1024), Cfg(c))
                rv.setImageViewBitmap(R.id.img, bmp)
            }
            m.updateAppWidget(id, rv)
        }
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: Bundle) {
        onUpdate(c, m, intArrayOf(id))
    }
}
