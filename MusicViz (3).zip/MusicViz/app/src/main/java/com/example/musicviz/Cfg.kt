package com.example.musicviz

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import kotlin.reflect.KProperty

/** Общее состояние для превью в приложении и диагностики. */
object Live {
    @Volatile var bmp: Bitmap? = null
    @Volatile var status = "Сервис не запущен"
    @Volatile var watching = false
}

class IntPref(private val p: SharedPreferences, private val k: String, private val d: Int) {
    operator fun getValue(t: Any?, prop: KProperty<*>): Int = p.getInt(k, d)
    operator fun setValue(t: Any?, prop: KProperty<*>, v: Int) { p.edit().putInt(k, v).apply() }
}

/** Настройки (сервис читает их на лету, перезапуск не нужен). */
class Cfg(c: Context) {
    private val p = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    var mode by IntPref(p, "mode", 0)
    var source by IntPref(p, "src", 0)      // 0 авто, 1 Visualizer, 2 микрофон
    var sens by IntPref(p, "sens", 60)
    var smooth by IntPref(p, "smooth", 60)
    var alpha by IntPref(p, "alpha", 100)   // непрозрачность, %
    var bg by IntPref(p, "bg", 0)           // затемнение фона, %
    var bars by IntPref(p, "bars", 24)      // 8..32
    var fps by IntPref(p, "fps", 2)         // индекс в VisualizerService.FPS
    var grad by IntPref(p, "g", 1)
    var colorA by IntPref(p, "a", 0xFF00E5FF.toInt())
    var colorB by IntPref(p, "b", 0xFFFF4081.toInt())
}
